#include<stdio.h>
#include<math.h>
int main()
{
    int i, m;
    long long int k;

    scanf("%d %d", &i, &k);

    k = pow (i, m);

    printf("%ld", k);

    return 0;
}