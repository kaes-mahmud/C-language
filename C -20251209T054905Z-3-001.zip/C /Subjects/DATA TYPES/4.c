#include<stdio.h>
int main()
{
    int v,a,b,c,d;

    scanf("%d",a);
    scanf("%d",b);
    scanf("%d",c);
    scanf("%d",d);

    v = (a * a) + 2 * (a * b) + (c - d);

    printf("%d",v);

    return 0;
}