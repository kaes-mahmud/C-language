// Number System - Palindrome Number

#include<stdio.h>
int main()
{
    int i, n, r = 0, rem;

    scanf("%d", &n);

    for (i = n; i != 0;)
    {
        rem = i % 10;
        r = (r * 10) + rem;
        i = i / 10;
    }

    if (r == n)
    {
        printf("Palindrome Number");
    }

    else
    {
        printf("Not Palindrome Number");
    }

    return 0;
}