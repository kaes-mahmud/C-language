#include<stdio.h>
#include<math.h>

int main()
{
    int x, y, a, c;
    float m, n, z;

    printf("Select your operation: \n");
    printf("___________________________\n");
    printf("Select 1 for Power\n");
    printf("Select 2 for Addition\n");
    printf("Select 3 for Division\n");
    printf("Select 4 for Multiplication\n");
    printf("___________________________\n");

    scanf("%d", &c);

    switch (c)
    {
    case 1:
        printf("Input two numbers for Power: ");
        scanf("%d %d", &x, &y);

        a = pow(x,y);
        printf("The result is : %d",a);

        break;

    case 2:
        printf("Input two numbers for Addition: ");
        scanf("%d %d", &x, &y);

        a = x + y;
        printf("The result is : %d",a);

        break;

    case 3:
        printf("Input two numbers for Division: ");
        scanf("%f %f", &m, &n);

        z = m / n;
        printf("The result is : %.2f",z);

        break;

    case 4:
        printf("Input two numbers for Multiplication: ");
        scanf("%d %d", &x, &y);

        a = x * y;
        printf("The result is : %d",a);

        break;

    default:
        printf("Your Operation selection is wrong or your input is invalid");

        break;
    }

    return 0;
}