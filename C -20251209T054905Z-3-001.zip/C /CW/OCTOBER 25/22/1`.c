#include<stdio.h> // include --> keywords, <stdio.h> --> keywords
int main() // int --> keywords, main --> 
{ // { --> punctuators
    int x = 10; // int --> keywords, x --> identifiers, = --> assignment operator, 10 --> constant, ; --> punctuators
    float ifti = 7.3; // float --> keywords, ifti --> identifiers, = --> assignment operator, 7.3 --> constant, ; --> punctuators

    printf("%d", x); // printf --> keywords, () --> punctuators, "%d" --> keywords, x --> identifiers, ; --> punctuators

    return 0; // return --> keywords, 0 --> constant, ; --> punctuators
} // } --> punctuators