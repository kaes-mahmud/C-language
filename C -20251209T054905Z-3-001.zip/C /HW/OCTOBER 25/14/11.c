// 11. Write a C program to calculate profit and loss on a transaction.
// Test Data : 500 700
// Expected Output : You can booked your profit amount : 200

#include<stdio.h>
int main()
{
    float cost_price, selling_price, amount;

    printf("Enter the Cost price: ");
    scanf("%f", &cost_price);

    printf("Enter the Selling Price: ");
    scanf("%f", &selling_price);

    if (selling_price > cost_price)
    {
        amount = selling_price - cost_price;
        printf("You can booked your profit amount : %.2f", amount);
    }
    else if (cost_price > selling_price)
    {
        amount = cost_price - selling_price;
        printf("You have incurred a loss of amount : %.2f", amount);
    }
    else
    {
        printf("No profit, no loss in the transaction.");
    }

    return 0;
}