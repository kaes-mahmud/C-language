#include<stdio.h>
int main()
{
    int x = 10;
    int y = 5;

    int z = x/y;

    printf("%d", z);

    return 0;
}
