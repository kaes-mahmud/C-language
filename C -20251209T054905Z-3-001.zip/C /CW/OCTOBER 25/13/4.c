// 4. A student will input his marks. Output will be his grade.

#include<stdio.h>
int main()
{
    int num;

    scanf("%d", &num);

    if (num >= 80 && num <= 100)
    {
        printf("A+");
    }
    else if (num >= 75 && num <= 79)
    {
        printf("A");
    }
    else if (num >= 70 && num <= 74)
    {
        printf("A-");
    }
    else if (num >= 60 && num <= 69)
    {
        printf("B");
    }
    else if (num >= 50 && num <= 59)
    {
        printf("C");
    }
    else if (num >= 40 && num <= 49)
    {
        printf("F");
    }
    else
    {
        printf("Your are not our student!");
    }

    return 0;
}