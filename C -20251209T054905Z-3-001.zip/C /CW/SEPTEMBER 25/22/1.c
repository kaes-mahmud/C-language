#include<stdio.h>
int main()
{
    int x = 7;
    int y = 10;
    float m = 9.7;

    printf("%d", x);
    printf("%d", y);
    printf("%d", m);

    return 0;
}