// 4. Write a C program to determine eligibility for admission to a professional course based on the following criteria: Go to the editor
// Eligibility Criteria : Marks in Maths >=65 and Marks in Phy >=55 and Marks in Chem>=50 and Total in all three subject >=190 or Total in Maths and Physics >=140.
// Input the marks obtained in Physics :65 Input the marks obtained in Chemistry :51 Input the marks obtained in Mathematics :72 Total marks of Maths, Physics and Chemistry : 188 Total marks of Maths and Physics : 137 The candidate is not eligible.
// Expected Output : The candidate is not eligible for admission.

#include<stdio.h>
int main()
{
    int math, physics, chemistry, all, total;
    
    printf("Input the marks obtained in Math: ");
    scanf("%d", &math);

    printf("Input the marks obtained in Physics: ");
    scanf("%d", &physics);

    printf("Input the marks obtained in Chemistry: ");
    scanf("%d", &chemistry);

    all = math + physics + chemistry;
    total = math + physics;

    printf("Total marks of Math, Physics & Chemistry: %d\n", all);
    printf("Total marks of Math & Physics: %d\n", total);

    if ((math >= 65 && physics >= 55 && chemistry >= 50) && (all >= 190 || total >= 140))
    {
        printf("The candidate is eligible for admission.");
    }
    else
    {
        printf("The candidate is not eligible for admission.");
    }

    return 0;
}