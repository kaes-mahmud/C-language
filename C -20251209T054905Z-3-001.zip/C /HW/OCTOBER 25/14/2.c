// 2. Write a C program to check whether a given number is positive or negative.
// Test Data : 15
// Expected Output : 15 is a positive number.

#include<stdio.h>
int main()
{
    int x;

    scanf("%d", &x);

    if (x > 0)
    {
        printf("Positive");
    }
    else if (x < 0)
    {
        printf("Negative");
    }
    else
    {
        printf("Error!");
    }

    return 0;
}