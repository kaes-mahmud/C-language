#include<stdio.h>
int main()
{
    int a = 10,b = 15,c = 20;
    float d = 25;

    printf("%d\n", a + b);
    printf("%d\n", b - a);
    printf("%f\n", c * d);
    printf("%f\n", d / a);

    return 0;
}