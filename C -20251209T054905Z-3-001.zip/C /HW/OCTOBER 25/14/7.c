// 7. Write a C program to check whether a triangle is Equilateral, Isosceles or Scalene.
// Test Data : 50 50 60
// Expected Output : This is an isosceles triangle.

#include<stdio.h>
int main()
{
    int angle1, angle2, angle3;

    printf("Enter 3 sides of the triangle: ");
    scanf("%d %d %d", &angle1, &angle2, &angle3);

    if (angle1 == angle2 && angle2 == angle3)
    {
        printf("This is an Equilateral triangle.");
    }
    else if (angle1 == angle2 || angle1 == angle3|| angle2 == angle3)
    {
        printf("This is an Isosceles triangle.");
    }
    else
    {
        printf("This is a Scalene triangle.");
    }

    return 0;
}