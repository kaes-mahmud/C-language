#include<stdio.h>
#include<math.h>
int main()
{
    double a = 2.1;
    double b = 2.5;
    double c = 2.6;
    double d = 2.9;

    printf("%lf\n", round(a));
    printf("%lf\n", round(b));
    printf("%lf\n", round(c));
    printf("%lf\n", round(d));

    return 0;
}