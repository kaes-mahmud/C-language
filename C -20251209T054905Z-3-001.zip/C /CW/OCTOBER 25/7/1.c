#include<stdio.h>
#include<math.h>

int main()
{
    int x,k;

    scanf("%d",&x);

    k =  sqrt(x);
    printf("%d\n",k);

    return 0;
}
