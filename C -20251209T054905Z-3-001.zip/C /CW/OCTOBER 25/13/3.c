// 3. Write a C program where user will give you his age you need to declare if he is eligible for vote or not.

#include<stdio.h>
int main()
{
    int age;
    
    scanf("%d", &age);

    if (age >= 18)
    {
        printf("You are eligible for vote");
    }
    else
    {
        printf("You are not eligible for vote");
    }

    return 0;
}