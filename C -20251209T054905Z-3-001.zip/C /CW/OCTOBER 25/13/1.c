// 1. Write a C program wheather a number is odd or even.

#include<stdio.h>
int main()
{
    int i;
    
    scanf("%d", &i);
    
    if (i % 2 == 0)
    {
        printf("Odd");
    }
    else
    {
        printf("Even");
    }

    return 0;
}