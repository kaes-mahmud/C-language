#include<stdio.h>
#include<math.h>
int main()
{
    double a = 2.1;
    double b = 2.5;
    double c = 2.6;
    double d = 2.9;

    printf("%lf\n", ceil(a));
    printf("%lf\n", ceil(b));
    printf("%lf\n", ceil(c));
    printf("%lf\n", ceil(d));

    return 0;
}