#include<stdio.h>
int main()
{
    int x;
    float y;
    scanf("%d", &x);
    scanf("%f", &y);
    printf("%d\n", x);
    printf("%f\n", y);

    return 0;
}
