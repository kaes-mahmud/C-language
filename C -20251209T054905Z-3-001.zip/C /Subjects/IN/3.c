#include<stdio.h>
int main()
{
    int a = 10;
    int b = -20;
    int c = 30;
    int d = -40;
    int e = 50;

    float f = 1.2;
    float g = -2.3;
    float h = 3.4;
    float i = -4.5;
    float j = 5.6;

    char k = 'C';
    char l = 'S';
    char m = 'E';
    char n = '3';
    char o = '7';

    long int p = 1617339746;
    long int q = -1920160766;
    long int r = 1622772453;
    long int s = -1682300777;
    long int t = 1915424715;

    printf("%d\n", a);
    printf("%d\n", b);
    printf("%d\n", c);
    printf("%d\n", d);
    printf("%d\n", e);

    printf("%f\n", f);
    printf("%f\n", g);
    printf("%f\n", h);
    printf("%f\n", i);
    printf("%f\n", j);

    printf("%c\n", k);
    printf("%c\n", l);
    printf("%c\n", m);
    printf("%c\n", n);
    printf("%c\n", o);

    printf("%ld\n", p);
    printf("%ld\n", q);
    printf("%ld\n", r);
    printf("%ld\n", s);
    printf("%ld\n", t);

    return 0;
}

