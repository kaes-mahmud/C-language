#include <stdio.h>
int main()
{
    int x = 10;
    int y = 90;
    float k = 9.8;
    char p = 'F';
    double m = 234324.434;

    printf("My age is : %d\n", x);
    printf("My grandpa's age is : %d\n", y);
    printf("My sister's age is : %f\n", k);
    printf("Gender : %c\n", p);
    printf("Answer of the question is : %lf\n", m);

    return 0;
}
