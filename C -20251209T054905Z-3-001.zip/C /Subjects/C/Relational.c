#include<stdio.h>
int main()
{
    int a = 10, b = 20, c, d, e, f;

    c = a < b;
    d = b > a;
    e = a <= b;
    f = b >= a;

    printf("%d\n", c);
    printf("%d\n", d);
    printf("%d\n", e);
    printf("%d\n", f);

    return 0;
}