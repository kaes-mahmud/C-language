// 10. Write a C program to check whether an alphabet is a vowel or a consonant.
// Test Data : k
// Expected Output : The alphabet is a consonant.

#include<stdio.h>
int main()
{
    char a;

    scanf("%c", &a);

    if (a == 'A' || a == 'E' || a == 'I' || a == 'O' || a == 'U' || a == 'a' || a == 'e' || a == 'i' || a == 'o' || a == 'u')
    {
        printf("Vowel");
    }
    else
    {
        printf("Consonant");
    }

    return 0;
}