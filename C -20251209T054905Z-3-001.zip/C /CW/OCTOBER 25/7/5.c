#include<stdio.h>
#include<math.h>

int main()
{
    int a,b,c,x,e,f,g,h,m,n;
    float y;

    scanf("%d %d %d %d",&a,&b,&c,&x);

    e = pow(b,2);
    f = c * a;
    g = sqrt(x);

    h = e / f;
    y = h + g;

    //y = (pow(b,2)) / (c * a) + (sqrt(x));

    printf("%f\n", y);

    m = floor(y);

    printf("%d\n", m);

    n = round(y);

    printf("%d", n);

    return 0;
}
