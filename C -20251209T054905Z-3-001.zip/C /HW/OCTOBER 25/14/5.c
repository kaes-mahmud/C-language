// 5. Write a C program to calculate the root of a quadratic equation.
// Test Data : 1 5 7
// Expected Output : Root are imaginary; No solution.

#include<stdio.h>
#include<math.h>
int main()
{
    int a, b, c, f;
    float x1, x2;

    printf("Type the value of a, b & c form the equation: ");
    scanf("%d %d %d", &a, &b, &c);

    f = b * b - 4 * a * c;

    if (f == 0)
    {
        printf("Both roots are equal.\n");
        
        x1 = - b / (2.0 * a);
        x2 = x1;
        
        printf("Root 1 = %f\n", x1);
        printf("Root 2 = %f \n", x2);
    }
    else if (f > 0)
    {
        printf("Both roots are real and different.\n");
        
        x1 = (- b + sqrt(f)) / (2 * a);
        x2 = (- b - sqrt(f)) / (2 * a);

        printf("Root 1 = %f\n", x1);
        printf("Root 2 = %f\n", x2);
    }
    else
    {
        printf("No answer.");
    }

    return 0;
}