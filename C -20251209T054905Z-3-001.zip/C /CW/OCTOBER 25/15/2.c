#include<stdio.h>
int main()
{
    printf("Please select your operation:\n");
    printf("________________________________\n");
    printf("Press - 1 : Area of a Circle\n");
    printf("Press - 1 : Area of a Triangle\n");
    printf("Press - 1 : Area of a Square\n");
    printf("Press - 1 : Area of a Rectangle\n");


    int op, b, h, x, r, l, p;
    float a;

    scanf("%d", &op);

    if(op == 1)
    {
        printf("Please enter the radius of Circle: \n");
        scanf("%d", &r);
        a = 3.1416 * r * r
    }
    else if (op == 2)
    {
        printf("Please enter the radius of Triangle: \n");
        scanf("%d %d", &b &h);
        a = .5 * b * h;
    }
    else if (op == 3)
    {
        printf("Please enter the radius of Square: \n");
        scanf("%d", &x);
        a = x * x;
    }
    else if (op == 4)
    {
        printf("Please enter the radius of Rectangle: \n");
        scanf()
    }

    return 0;
}