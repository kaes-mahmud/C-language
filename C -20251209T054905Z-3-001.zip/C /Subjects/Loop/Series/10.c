// Series Problem

#include<stdio.h>
#include<math.h>
int main()
{
    int i, j, k = 0, n;
    long long sum = 0;

    scanf("%d", &n);

    if (n <= 0)
    {
        return 1;
    }

    for (i = 1, j = 2; k < n; i += 2, j +=2)
    {
        sum += (long long)pow(i, j);

        k++;
    }

    printf("%lld", sum);

    return 0;
}