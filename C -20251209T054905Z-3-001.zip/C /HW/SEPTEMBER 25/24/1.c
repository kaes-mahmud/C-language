#include<stdio.h>
int main()
{
    int x;
    char i;

    x = sizeof(i);
    
    printf("%d", x);
    
    return 0;
}