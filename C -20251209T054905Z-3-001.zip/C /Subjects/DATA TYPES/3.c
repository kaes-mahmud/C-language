#include<stdio.h>
int main()
{
    int u,t,a;
    float s;

    scanf("%d",&u);
    scanf("%d",&t);
    scanf("%d",&a);

    s = (u * t) + (0.5 * (a * (t * t)));

    printf("%f", s);

    return 0;
}