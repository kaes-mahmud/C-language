#include<stdio.h>
int main()
{
    float b, bx, bx1, u;

    scanf("%f", &u);

    if (u < 200)
    {
        bx = u * 1.20;
    }
    else if (u < 400)
    {
        bx = u * 1.59;
    }
    else if (u < 600)
    {
        bx = u * 1.80;
    }
    else
    {
        bx = u * 2.00;
    }

    if (bx > 400)
    {
        bx1 = (bx * (15 / 100)) + bx;
    }
    else
    {
        bx1 = bx;
    }

    if (bx1 <= 100)
    {
        b = 100;
    }
    else
    {
        b = bx1;
    }

    return 0;
}