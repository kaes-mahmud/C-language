#include<stdio.h>
int main()
{
    int i;
    for (i = 1; i <= 10000000; i++)
    {
        printf("%d", i);
        delay (50);
    }

    return 0;
}