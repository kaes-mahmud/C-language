// Number System - Prime Number

#include<stdio.h>
int main()
{
    int i, n, x = 0;

    scanf("%d", &n);

    for (i = 2; i < n; i++)
    {
        if (n % i == 0)
        {
            x++;
        }
    }

    if (x == 0)
    {
        printf("PRIME");
    }
    
    else
    {
        printf("NOT PRIME");
    }
}