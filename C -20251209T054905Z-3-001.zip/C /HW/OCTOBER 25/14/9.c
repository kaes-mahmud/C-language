// 9. Write a C program to check whether a character is an alphabet, digit or special character.
// Test Data : @
// Expected Output : This is a special character.

#include<stdio.h>
int main()
{
    char x;

    printf("Enter a character: ");
    scanf("%c", &x);

    if ((x >= 'A' && x <= 'Z') || (x >= 'a' && x <= 'z'))
    {
        printf("This is an alphabet.");
    }
    else if (x >= '0' && x <= '9')
    {
        printf("This is a digit.");
    }
    else
    {
        printf("This is a special character.");
    }

    return 0;
}