#include<stdio.h>
int main()
{
    // = hocche jodi 2 tar maan shoman bujhate chai
    // ! hocche jodi 2 tar maan shoman na thake

    int a = 15,b = 20,c = 37, d, e, f, g;

    d = a += 5;
    e = b -= 5;
    f = c *= 2;
    g = a /= 5;

    printf("%d\n", d);
    printf("%d\n", e);
    printf("%d\n", f);
    printf("%d\n", g);

    return 0;
}