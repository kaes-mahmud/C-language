// Digit Cutting

#include<stdio.h>
int main()
{
    int n, rem;

    scanf("%d", &n);

    for (; n > 0;)
    {
        rem = n % 10;
        n = n / 10;

        printf("%d ", rem);
    }

    return 0;
}