// 1. Write a C program to accept two integers and check whether they are equal or not.
// Test Data : 15 15
// Expected Output : Number1 and Number2 are equal.

#include<stdio.h>
int main()
{
    int m, n;

    scanf("%d %d", &m, &n);

    if (m == n)
    {
        printf("Equal");
    }
    else
    {
        printf("Not Equal");
    }

    return 0;
}