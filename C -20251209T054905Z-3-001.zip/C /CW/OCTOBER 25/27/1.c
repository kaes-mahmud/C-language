#include<stdio.h>
#include<math.h>
int main()

{
    int x, y, z;
    float w;

    printf("A simple operation\n");
    printf("_________________________\n");
    printf("Select 1 : Addition\n");
    printf("Select 2 : Subtraction\n");
    printf("Select 3 : Multiplication\n");
    printf("Select 4 : Division\n");
    printf("Select 5 : Root\n");
    printf("_________________________\n");

    int n;

    scanf("%d", &n);

    switch (n)
    {
    case 1:
        printf("Enter two numbers for addition : \n");
        scanf("%d %d", &x, &y);

        z = x + y;

        printf("%d", z);

        break;

    case 2:
        printf("Enter two numbers for subtraction : \n");
        scanf("%d %d", &x, &y);

        z = x - y;

        printf("%d", z);

        break;

    case 3:
        printf("Enter two numbers for multiplication : \n");
        scanf("%d %d", &x, &y);

        z = x * y;

        printf("%d", z);

        break;

    case 4:
        printf("Enter two numbers for divison : \n");
        scanf("%d %d", &x, &y);

        w = x / y;

        printf("%f", w);

        break;

    case 5:
        printf("Enter a number that you want to root\n");
        scanf("%d", &x);

        z = sqrt (x);

        printf("%d", z);

        break;

    default:

        printf("Please select a valid operation.");

        break;
    }

    return 0;
}