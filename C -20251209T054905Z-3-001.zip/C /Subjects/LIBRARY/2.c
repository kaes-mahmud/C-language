#include<stdio.h>
#include<math.h>
int main()
{
    double a = 2.1;
    double b = 2.5;
    double c = 2.6;
    double d = 2.9;

    printf("%lf\n", floor(a));
    printf("%lf\n", floor(b));
    printf("%lf\n", floor(c));
    printf("%lf\n", floor(d));

    return 0;
}