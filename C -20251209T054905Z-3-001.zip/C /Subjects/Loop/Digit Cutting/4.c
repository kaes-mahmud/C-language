// Digit Cutting

#include<stdio.h>
int main()
{
	long long int a, b, c, i, odd=0, even=0, x, y, z;

	scanf("%lld", &a);

	for (b = 9; b >= 1; b -= 2)
	{
		for (i = a; i > 0; i = i / 10)
		{
			c = i % 10;
			if (b == c)
				odd = odd * 10 + c;
		}
	}

	for (b = 0; b <= 8; b += 2)
		{
			for (i = a; i > 0; i = i / 10)
			{
				c=i % 10;
				if (b == c)
					even = even * 10 + c;
			}
		 }

	printf("Largest odd number %lld", odd);
	printf("\nSmallest even number %lld", even);

	return 0;
}