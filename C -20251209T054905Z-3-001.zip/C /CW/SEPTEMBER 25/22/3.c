#include <stdio.h>
int main()
{
    int a = 252071007;
    char b = 'M';
    int c = 2023;
    float d = 3.67;

    printf("Hello, My roll is : %d\n", a);
    printf("My gender is : %c\n", b);
    printf("In the year of %d I completed my HSC exam\n", c);
    printf("My GPA is : %f\n", d);

    return 0;
}
