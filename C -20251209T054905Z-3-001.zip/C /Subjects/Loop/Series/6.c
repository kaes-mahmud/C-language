// Series Problem

#include<stdio.h>
#include<math.h>
int main()
{
    int i, j, m, n, sum = 0;

    scanf("%d", &n);

    for (i = 1, j = 2; i <= n; i++)
    {
        m = pow(i, j);
        sum += m;
    }

    printf("%d", sum);
}