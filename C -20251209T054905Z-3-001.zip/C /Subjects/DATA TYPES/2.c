#include<stdio.h>
int main()
{
    int v,u,a,t,v1;

    scanf("%d",&u);
    scanf("%d",&a);
    scanf("%d",&t);

    v1 = a * t;
    v = u + v1;

    printf("%d", v);

    return 0;
}