#include<stdio.h>
#include<math.h>
int main()
{
    double a = 2;
    double b = 3;
    double c = 5;
    double d = 9;

    printf("%lf\n", pow(a, 3));
    printf("%lf\n", pow(b, 2));
    printf("%lf\n", pow(c, 5));
    printf("%lf\n", pow(d, 9));

    return 0;
}