#include<stdio.h>
int main()
{
    int i;
    float j;

    scanf("%d",&i);
    scanf("%f",&j);

    printf("%d\n%f",i,j);

    return 0;
}
