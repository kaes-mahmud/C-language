// Series Problem

#include<stdio.h>
int main()
{
    int i, j = 0, n, sum = 0;

    scanf("%d", &n);

    for (i = 1; j < n; i++)
    {
        if (i % 2 == 1)
        {
            j++;

            if (j < n)
            {
            }

            sum += i;
        }
    }

    printf("%d", sum);

    return 0;
}