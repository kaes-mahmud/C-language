// 8. Write a C program to check whether a triangle can be formed with the given values for the angles.
// Test Data : 40 55 65
// Expected Output : The triangle is not valid.

#include<stdio.h>
int main()
{
    int angle1, angle2, angle3, sum;

    printf("Enter three angles of a triangle: ");
    scanf("%d %d %d", &angle1, &angle2, &angle3);

    sum = angle1 + angle2 + angle3;

    if (sum == 180 && angle1 > 0 && angle2 > 0 && angle3 > 0)
    {
        printf("The triangle is valid.");
    }
    else
    {
        printf("The triangle is not valid.");
    }

    return 0;
}