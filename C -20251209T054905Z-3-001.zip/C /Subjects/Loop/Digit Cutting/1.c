// Digit Cutting

#include<stdio.h>
int main()
{
    int n, r, sum = 0, t;

    printf("Input a number : ");
    
    scanf("%d",&n);
    
    for (t = n; n != 0; n = n / 10)
    {
        r = n % 10;
        sum = sum * 10 + r;
    }

    printf("%d", sum);
    
    return 0;
}