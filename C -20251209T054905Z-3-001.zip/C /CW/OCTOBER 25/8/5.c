#include<stdio.h>
int main()
{
    int i;
    for (i = 65; i <= 90; i++)
    {
        printf("%d %c", i, i);
        delay (20);
    }
    
    return 0;
}