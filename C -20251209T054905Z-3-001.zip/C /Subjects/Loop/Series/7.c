// Series Problem

#include<stdio.h>
int main()
{
    int i, j, k = 0, n;

    scanf("%d", &n);

    for (i = 1, j = 2; k < n; i++)
    {
        if (i % 2 == 1)
        {
            printf("%d^%d", i, j);

            k++;

            if (k < n)
            {
                printf("+");
            }
        }
    }

    return 0;
}