#include<stdio.h>
int main()
{
    int i;
    scanf("%d", &i);

    if(i > 50)
    {
        if (i > 79)
        {
            printf("A+");
        }
        else if (i > 69)
        {
            printf("A");
        }
        else if (i > 59)
        {
            printf("B");
        } 
    }
    else
    {
        printf("%d", i);
    }

    return 0;
}