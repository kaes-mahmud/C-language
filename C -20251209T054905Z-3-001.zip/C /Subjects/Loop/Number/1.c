// Number System - Amstrong Number

#include<stdio.h>
#include<math.h>
int main()
{
    int i, n, rem, m = 0;
    double y = 0;

    scanf("%d", &n);

    for (i = n; i != 0; i = i / 10)
    {
        m++;
    }
        
    for (i = n; i != 0; i = i / 10)
    {
        rem = i % 10;

        y += pow(rem, m);
    }

    if ((int)y == n)
    {
        printf("This is a Armstrong Number");
    }

    else
    {
        printf("This is not a Armstrong Number");
    }

    return 0;
}