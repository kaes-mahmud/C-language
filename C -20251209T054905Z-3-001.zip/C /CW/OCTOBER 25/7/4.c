#include<stdio.h>
#include<math.h>

int main()
{
    int i, j, a, b;

    scanf("%d %d",&i,&j);

    i++;
    j++;

    printf("%d\n%d", i, j);

    return 0;
}
