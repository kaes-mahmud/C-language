// 2. Determine greater number between 3 numbers.

#include<stdio.h>
int main()
{
    int i,j,k;
    
    scanf("%d %d %d", &i, &j, &k);
    
    if (i > j && i > k)
    {
        printf("I is greater");
    }
    else if (j > k && j > i)
    {
        printf("J is greater");
    }
    else if (k > i && k > j)
    {
        printf("K is greater");
    }
    else
    {
        printf("Others...");
    }

    return 0;
}