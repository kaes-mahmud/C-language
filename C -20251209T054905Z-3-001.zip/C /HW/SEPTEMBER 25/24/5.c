#include<stdio.h>
#include<math.h>
int main()
{
    int u, a, s, v1, v2;
    float v;

    scanf("%d", &u);
    scanf("%d", &a);
    scanf("%d", &s);

    v1 = (u * u) + 2 * a * s;
    v2 = v1 * v1;
    v = sqrt (v2);

    printf("%f", v);

    return 0;
}