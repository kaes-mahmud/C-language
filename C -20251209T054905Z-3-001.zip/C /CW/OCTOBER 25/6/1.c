#include<stdio.h>
#include<math.h>
int main()
{
    int x;
    float y;
    
    scanf("%d", &x);

    y = sqrt(x);

    printf("%d", y);

    return 0;
}