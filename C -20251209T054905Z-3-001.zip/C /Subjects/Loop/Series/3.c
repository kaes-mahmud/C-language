// Series Problem

#include<stdio.h>
int main()
{
    int i, j = 0, n;

    scanf("%d", &n);

    for (i = 1; j < n; i++)
    {
        if (i % 2 == 1)
        {
            printf("%d", i);

            j++;

            if (j < n)
            {
                printf("+");
            }
        }
    }

    return 0;
}