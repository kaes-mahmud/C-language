// Digit Cutting

#include<stdio.h>
int main()
{
	int n, rem, orev = 0, erev = 0, orem, erem, n1 = 0, n2 = 0;

	scanf("%d", &n);

	for (int i = n; i > 0; i = i / 10)
	{
		rem = i % 10;
	
	    if (rem % 2 == 1)
	    {
		    orev = orev * 10;
		    orev = orev + rem;
	    }
	    else 
	    {
		    erev = erev * 10;
		    erev = erev + rem;
	    }
    }

    for (int i = orev; i > 0; i = i / 10)
    {
    	orem = i % 10;
    	n1 = n1 * 10;
    	n1 = n1 + orem;
    }

    for (int i = erev; i > 0;i = i / 10)
    {
    	erem = i % 10;
    	n2 = n2 * 10;
    	n2 = n2 + erem;
    }

	printf("%d %d",n1,n2);
	
    return 0;
}