#include<stdio.h>
int main()
{
    int i = 10;
    char a1 = 'a', a2 = 'b', a3 = 'c', a4 = '6', a5 = '%', a6 = ' ';

    printf("%d", a1);
    printf("%d", a2);
    printf("%d", a3);
    printf("%d", a4);
    printf("%d", a5);
    printf("%d", a6);

    return 0;
}