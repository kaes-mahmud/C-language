// Series Problem

#include<stdio.h>
int main()
{
    int i, k = 0, n;
    long long sum = 0;

    scanf("%d", &n);

    if (n <= 0)
    {
        return 1;
    }

    for (i = 1; k < n; i += 2)
    {
        sum += (long long)i * i;

        k++;
    }
    
    printf("%lld", sum);

    return 0;
}