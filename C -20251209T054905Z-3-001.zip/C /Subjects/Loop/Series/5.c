// Series Problem

#include<stdio.h>
int main()
{
    int i, j, n;

    scanf("%d", &n);

    for (i = 1, j = 2; i <= n; i++)
    {
        if (i < n)
        {
            printf("%d^%d+", i, j);
        }

        else
        {
            printf("%d^%d", i, j);
        }
    }
}