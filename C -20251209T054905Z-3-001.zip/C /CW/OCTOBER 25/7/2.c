#include<stdio.h>
#include<math.h>

int main()
{
    int i,j;
    float m;

    scanf("%d %d",&i,&j);

    m = pow(i,j);

    printf("%f",m);

    return 0;
}
