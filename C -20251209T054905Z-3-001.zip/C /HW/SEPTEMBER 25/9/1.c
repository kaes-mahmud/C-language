#include<stdio.h>

int main()
{
    printf("--------------------------------------------------- \n");
    printf("                  CURRICULUM VITAE                  \n");
    printf("--------------------------------------------------- \n");


    printf("Name: Iftekhar Ahmed Shihab \n");
    printf("Father's Name: Monir Ahmed \n");
    printf("Mother's Name: Papiya Sultana Rotna \n");
    printf("Date of Birth: 10.05.2005 \n");
    printf("Present Address: Dattapara, Tongi, Gazipur \n");
    printf("Permanent Address: Mandari Bazar, Laxmipur \n");
    printf("Nationality: Bangladeshi \n");
    printf("Blood Group: O+ \n");
    printf("Marital Status: Single \n");

    printf("--------------------------------------------------- \n");
    printf("                  Career Objective                  \n");
    printf("--------------------------------------------------- \n");


    printf("Ready to embark on a career in Computer Science & Engineering \n"
           "with a forward-thinking company that encourages learning and growth \n");

    printf("--------------------------------------------------- \n");
    printf("               Academic Qualification               \n");
    printf("--------------------------------------------------- \n");


    printf("EDUCATION:\n");
    printf(" __________________________________________ \n");
    printf("|   Exam   |   Board   | Result |   Year   |\n");
    printf("|__________|___________|________|__________|\n");
    printf("|   SSC    |   Dhaka   |  5.00  |   2021   |\n");
    printf("|   HSC    |   Dhaka   |  3.67  |   2023   |\n");
    printf("|   BSC    |   SMUCT   |  4.00  |   2029   |\n");
    printf("|__________|___________|________|__________|\n");

    printf("--------------------------------------------------- \n");
    printf("                      Experience                    \n");
    printf("--------------------------------------------------- \n");


    printf("C/C++ \n");
    printf("Python \n");
    printf("HTML \n");
    printf("CSS \n");
    printf("Java \n");
    printf("JavaScript \n");
    printf("WordPress \n");
    printf("Microsoft Word \n");
    printf("Microsoft Excel \n");
    printf("Microsoft PowerPoint \n");

    printf("--------------------------------------------------- \n");
    printf("                      Reference                     \n");
    printf("--------------------------------------------------- \n");


    printf("Iftekhar Ahmed Shihab\n");
    return 0;
}
