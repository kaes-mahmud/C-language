#include<stdio.h>
int main()
{
    int i = 10;
    char a = 'd';

    printf("%d", a);

    return 0;
}