#include<stdio.h>
int main()
{
    int x = 2;
    int y = 5;
    int z = 10;

    int a = x+y+z;

    printf("%d", a);
    return 0;
}
