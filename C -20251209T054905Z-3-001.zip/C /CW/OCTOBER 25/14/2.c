// 2. Write a program in C to accept a grade and declare the equivalent description.

#include<stdio.h>
int main()
{
    char grade;

    scanf("%c", &grade);

    if (grade == 'E')
    {
        printf("Excellent");
    }
    else if (grade == 'V')
    {
        printf("Very Good");
    }
    else if (grade == 'G')
    {
        printf("Good");
    }
    else if (grade == 'A')
    {
        printf("Average");
    }
    else if (grade == 'F')
    {
        printf("Fail");
    }
    else
    {
        printf("Your data doesn't match with our system");
    }

    return 0;
}