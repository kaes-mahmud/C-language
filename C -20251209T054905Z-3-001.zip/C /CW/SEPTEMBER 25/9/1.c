#include<stdio.h>
int main()
{
    printf(" __________________________________________ \n");
    printf("|   Exam   |   Board   | Result |   Year   |\n");
    printf("|__________|___________|________|__________|\n");
    printf("|   SSC    |   Dhaka   |  5.00  |   2021   |\n");
    printf("|   HSC    |   Dhaka   |  3.67  |   2023   |\n");
    printf("|   BSC    |   SMUCT   |  4.00  |   2029   |\n");
    printf("|__________|___________|________|__________|\n");

    return 0;
}