#include<stdio.h>
int main()
{
    int age;
    char gender;

    printf("Enter your age: ");
    scanf("%d", &age);

    printf("Enter your gender: ");
    scanf(" %c", &gender);

    if (age >= 0 && age <= 10)
    {
        printf("Enter room no 1002\n");
        if (gender == 'F')
        {
            printf("Booth no 10");
        }
        else if (gender == 'M')
        {
            printf("Booth no 12");
        }
    }

    else if (age >= 11 && age <= 30)
    {
        printf("Enter room no 2005\n");
        if (gender == 'F')
        {
            printf("Booth no 13");
        }
        else if (gender == 'M')
        {
            printf("Booth no 14");
        }
    }

    else if (age >= 31 && age <= 60)
    {
        printf("Enter room no 3007\n");
        if (gender == 'F')
        {
            printf("Booth no 15");
        }
        else if (gender == 'M')
        {
            printf("Booth no 16");
        }
    }

    else
    {
        printf("You are not HUMAN");
    }

    return 0;
}