#include<stdio.h>
int main()
{
    int i, j, k, sub, m, div;

    scanf("%d", &i);
    scanf("%d", &j);

    k = i + j;
    sub = i - j;
    m = i * j;
    div = i / j;

    printf("%d %d %d %d", k, sub, m, div);
    
    return 0;
}