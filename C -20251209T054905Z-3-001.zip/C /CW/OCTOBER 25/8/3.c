#include<stdio.h>
int main()
{
    int i = 65;

    printf("%c", i);

    return 0;
}